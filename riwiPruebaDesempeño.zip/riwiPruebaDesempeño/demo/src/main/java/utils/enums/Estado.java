package utils.enums;

public enum Estado {
    DISPONIBLE,
    EN_USO,
    DAÑADO,
    PENDIENTE,
    EN_TRANSPORTE,
    ENTREGADO
}
