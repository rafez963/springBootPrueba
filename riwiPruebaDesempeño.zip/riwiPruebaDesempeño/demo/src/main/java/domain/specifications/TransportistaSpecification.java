package domain.specifications;

import domain.entities.Transportista;
import org.springframework.data.jpa.domain.Specification;

public class TransportistaSpecification {


    public static Specification<Transportista> withNombre(String nombre) {
        return (root, query, builder) -> {
            if (nombre == null || nombre.isEmpty()) {
                return builder.conjunction();
            }
            return builder.like(root.get("nombre"), "%" + nombre + "%");
        };
    }

    public static Specification<Transportista> withTelefono(String telefono) {
        return (root, query, builder) -> {
            if (telefono == null || telefono.isEmpty()) {
                return builder.conjunction();
            }
            return builder.equal(root.get("telefono"), telefono);
        };
    }

    public static Specification<Transportista> withEmail(String email) {
        return (root, query, builder) -> {
            if (email == null || email.isEmpty()) {
                return builder.conjunction();
            }
            return builder.equal(root.get("email"), email);
        };
    }
}
