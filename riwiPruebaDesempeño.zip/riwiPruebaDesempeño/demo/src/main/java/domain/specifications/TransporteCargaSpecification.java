package domain.specifications;

import domain.entities.Carga;
import domain.entities.TransporteCarga;
import domain.entities.Transportista;
import org.springframework.data.jpa.domain.Specification;

import java.time.LocalDateTime;

public class TransporteCargaSpecification {

    // Filtrar por Transportista
    public static Specification<TransporteCarga> withTransportista(Transportista transportista) {
        return (root, query, builder) -> {
            if (transportista == null) {
                return builder.conjunction();
            }
            return builder.equal(root.get("transportista"), transportista);
        };
    }

    // Filtrar por Carga
    public static Specification<TransporteCarga> withCarga(Carga carga) {
        return (root, query, builder) -> {
            if (carga == null) {
                return builder.conjunction();
            }
            return builder.equal(root.get("carga"), carga);
        };
    }

    // Filtrar por fecha de transporte (rango de fechas)
    public static Specification<TransporteCarga> withFechaTransporteBetween(LocalDateTime fechaInicio, LocalDateTime fechaFin) {
        return (root, query, builder) -> {
            if (fechaInicio == null || fechaFin == null) {
                return builder.conjunction();
            }
            return builder.between(root.get("fechaTransporte"), fechaInicio, fechaFin);
        };
    }

    // Filtrar por el estado de la carga (si la carga está en un estado específico)
    public static Specification<TransporteCarga> withEstadoCarga(String estado) {
        return (root, query, builder) -> {
            if (estado == null || estado.isEmpty()) {
                return builder.conjunction();
            }
            return builder.equal(root.get("carga").get("estado"), estado);
        };
    }
}
