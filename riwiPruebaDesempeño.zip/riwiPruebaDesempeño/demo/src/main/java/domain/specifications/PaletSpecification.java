package domain.specifications;

import domain.entities.Palet;
import org.springframework.data.jpa.domain.Specification;
import utils.enums.Estado;

public class PaletSpecification {

    public static Specification<Palet> withEstado(Estado estado) {
        return (root, query, builder) -> {
            if (estado == null) {
                return builder.conjunction();
            }
            return builder.equal(root.get("estado"), estado);
        };
    }

    public static Specification<Palet> withCapacidadMaximaGreaterThanEqual(Double capacidadMinima) {
        return (root, query, builder) -> {
            if (capacidadMinima == null) {
                return builder.conjunction();
            }
            return builder.greaterThanOrEqualTo(root.get("capacidadMaxima"), capacidadMinima);
        };
    }

    public static Specification<Palet> withUbicacion(String ubicacion) {
        return (root, query, builder) -> {
            if (ubicacion == null || ubicacion.isEmpty()) {
                return builder.conjunction();
            }
            return builder.like(root.get("ubicacion"), "%" + ubicacion + "%");
        };
    }
}
