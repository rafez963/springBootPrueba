package domain.specifications;

import domain.entities.Carga;
import org.springframework.data.jpa.domain.Specification;
import utils.enums.Estado;

import java.util.Date;

public class CargaSpecification {

    public static Specification<Carga> withEstado(Estado estado) {
        return (root, query, builder) -> {
            if (estado == null) {
                return builder.conjunction();
            }
            return builder.equal(root.get("estado"), estado);
        };
    }

    public static Specification<Carga> withPesoLessThanEqual(Double pesoMaximo) {
        return (root, query, builder) -> {
            if (pesoMaximo == null) {
                return builder.conjunction();
            }
            return builder.lessThanOrEqualTo(root.get("peso"), pesoMaximo);
        };
    }

    public static Specification<Carga> withPaletId(Long paletId) {
        return (root, query, builder) -> {
            if (paletId == null) {
                return builder.conjunction();
            }
            return builder.equal(root.get("palet").get("idPalet"), paletId);
        };
    }
}
