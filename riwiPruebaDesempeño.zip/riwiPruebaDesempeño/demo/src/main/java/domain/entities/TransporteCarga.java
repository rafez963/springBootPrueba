package domain.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TransporteCarga {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idTransporte; // Identificador único para cada registro de transporte

    @ManyToOne
    @JoinColumn(name = "id_carga")
    private Carga carga; // Relación con la entidad Carga

    @ManyToOne
    @JoinColumn(name = "id_transportista")
    private Transportista transportista; // Relación con la entidad Transportista

    @Column(name = "fecha_transporte", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private LocalDateTime fechaTransporte; // Fecha y hora del transporte

    public TransporteCarga() {
    }

    public TransporteCarga(Long idTransporte, Carga carga, Transportista transportista, LocalDateTime fechaTransporte) {
        this.idTransporte = idTransporte;
        this.carga = carga;
        this.transportista = transportista;
        this.fechaTransporte = fechaTransporte;
    }

    public Long getIdTransporte() {
        return idTransporte;
    }

    public void setIdTransporte(Long idTransporte) {
        this.idTransporte = idTransporte;
    }

    public Carga getCarga() {
        return carga;
    }

    public void setCarga(Carga carga) {
        this.carga = carga;
    }

    public Transportista getTransportista() {
        return transportista;
    }

    public void setTransportista(Transportista transportista) {
        this.transportista = transportista;
    }

    public LocalDateTime getFechaTransporte() {
        return fechaTransporte;
    }

    public void setFechaTransporte(LocalDateTime fechaTransporte) {
        this.fechaTransporte = fechaTransporte;
    }
}
