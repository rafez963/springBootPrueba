package domain.entities;

import jakarta.persistence.*;
import lombok.*;
import utils.enums.Estado;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class Carga {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idCarga;

    @Column(nullable = false)
    private double peso;

    @Column(nullable = false)
    private String dimensiones; // Ej: "Largo x Ancho x Alto"

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Estado estado; // Utilizando el enum Estado

    @ManyToOne
    @JoinColumn(name = "id_palet")
    private Palet palet;

    public Carga() {
    }

    public Carga(Long idCarga, double peso, String dimensiones, Estado estado, Palet palet) {
        this.idCarga = idCarga;
        this.peso = peso;
        this.dimensiones = dimensiones;
        this.estado = estado;
        this.palet = palet;
    }

    public Long getIdCarga() {
        return idCarga;
    }

    public void setIdCarga(Long idCarga) {
        this.idCarga = idCarga;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public String getDimensiones() {
        return dimensiones;
    }

    public void setDimensiones(String dimensiones) {
        this.dimensiones = dimensiones;
    }

    public Estado getEstado() {
        return estado;
    }

    public void setEstado(Estado estado) {
        this.estado = estado;
    }

    public Palet getPalet() {
        return palet;
    }

    public void setPalet(Palet palet) {
        this.palet = palet;
    }
}
