package domain.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import utils.enums.Estado;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Palet {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idPalet;

    @Column(nullable = false)
    private double capacidadMaxima;

    @Column(nullable = false)
    private String ubicacion;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Estado estado; // Utilizando el enum Estado

    @Column(name = "fecha_creacion", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private LocalDateTime fechaCreacion;

    public Palet() {
    }

    public Palet(Long idPalet, double capacidadMaxima, String ubicacion, Estado estado, LocalDateTime fechaCreacion) {
        this.idPalet = idPalet;
        this.capacidadMaxima = capacidadMaxima;
        this.ubicacion = ubicacion;
        this.estado = estado;
        this.fechaCreacion = fechaCreacion;
    }

    public Long getIdPalet() {
        return idPalet;
    }

    public void setIdPalet(Long idPalet) {
        this.idPalet = idPalet;
    }

    public double getCapacidadMaxima() {
        return capacidadMaxima;
    }

    public void setCapacidadMaxima(double capacidadMaxima) {
        this.capacidadMaxima = capacidadMaxima;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    public Estado getEstado() {
        return estado;
    }

    public void setEstado(Estado estado) {
        this.estado = estado;
    }

    public LocalDateTime getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(LocalDateTime fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }
}
