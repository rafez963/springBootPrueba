package api.controllers;

import api.dtos.PaletRequest;
import api.responses.PaletResponse;
import aplication.ports.PaletServicePort;
import domain.entities.Palet;
import io.swagger.annotations.ApiOperation;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;
import java.util.stream.Collectors;

public class PaletController {


    private final PaletServicePort paletService;

    public PaletController(PaletServicePort paletService) {
        this.paletService = paletService;
    }

    @ApiOperation("Obtener todos los palets")
    @GetMapping
    public ResponseEntity<List<PaletResponse>> getAllPallets() {
        List<PaletResponse> palets = paletService.obtenerTodosLosPalets().stream()
                .map(p -> new PaletResponse(p.getIdPalet(), p.getCapacidadMaxima(), p.getUbicacion(), p.getEstado().toString(), p.getFechaCreacion()))
                .collect(Collectors.toList());
        return ResponseEntity.ok(palets);
    }

    @ApiOperation("Obtener detalles de un palet específico")
    @GetMapping("/{id}")
    public ResponseEntity<PaletResponse> getPalletById(@PathVariable Long id) {
        return paletService.obtenerPaletPorId(id)
                .map(palet -> ResponseEntity.ok(new PaletResponse(palet.getIdPalet(), palet.getCapacidadMaxima(), palet.getUbicacion(), palet.getEstado().toString(), palet.getFechaCreacion())))
                .orElse(ResponseEntity.notFound().build());
    }

    @ApiOperation("Crear un nuevo palet")
    @PostMapping
    public ResponseEntity<PaletResponse> createPallet(@RequestBody PaletRequest request) {
        Palet palet = new Palet();
        palet.setCapacidadMaxima(request.getCapacidadMaxima());
        palet.setUbicacion(request.getUbicacion());
        palet.set()
        }
    }

