package api.dtos;

public class PaletRequest {

    private double capacidadMaxima;
    private String ubicacion;
    private String estado; // Puede ser "DISPONIBLE", "EN_USO", "DANADO"
}
