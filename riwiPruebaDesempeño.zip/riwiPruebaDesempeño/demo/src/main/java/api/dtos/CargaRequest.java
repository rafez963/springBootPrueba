package api.dtos;

public class CargaRequest {
    private double peso;
    private String dimensiones;
    private Long idPalet;
}
