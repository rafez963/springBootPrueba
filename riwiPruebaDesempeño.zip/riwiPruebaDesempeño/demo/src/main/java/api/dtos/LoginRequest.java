package api.dtos;

public class LoginRequest {
    private String email;
    private String password;
}
