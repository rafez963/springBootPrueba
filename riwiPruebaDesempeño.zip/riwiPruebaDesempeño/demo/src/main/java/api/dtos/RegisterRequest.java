package api.dtos;

public class RegisterRequest {

    private String email;
    private String password;
    private String role; // Puede ser "ADMIN" o "TRANSPORTISTA"

}
