package api.responses;

public class CargaResponse {
    private Long id;
    private double peso;
    private String dimensiones;
    private String estado; // Puede ser "PENDIENTE", "EN_TRANSITO", "ENTREGADO"
    private Long paletId;
}
