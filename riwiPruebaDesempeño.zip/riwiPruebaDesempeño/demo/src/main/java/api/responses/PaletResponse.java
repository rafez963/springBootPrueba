package api.responses;

import java.time.LocalDateTime;

public class PaletResponse {

    private Long id;
    private double capacidadMaxima;
    private String ubicacion;
    private String estado;
    private LocalDateTime fechaCreacion;

    public PaletResponse(Long idPalet, double capacidadMaxima, String ubicacion, String string, LocalDateTime fechaCreacion) {
    }
}
