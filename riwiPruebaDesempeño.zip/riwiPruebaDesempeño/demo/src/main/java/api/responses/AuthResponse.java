package api.responses;

public class AuthResponse {
    private String token;
}
