package infrastructure.persistence;

import domain.entities.Carga;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CustomCargaRepository extends JpaRepository<Carga, Long> {


}
