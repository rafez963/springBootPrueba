package infrastructure.persistence;

import domain.entities.Carga;
import domain.entities.Palet;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CustomPaletRepository extends JpaRepository<Palet, Long> {
}
