package aplication.services;

import aplication.ports.CargaServicePort;
import domain.entities.Carga;
import domain.repositories.CargaRepository;
import domain.specifications.CargaSpecification;
import org.springframework.data.jpa.domain.Specification;
import utils.enums.Estado;

import java.util.List;
import java.util.Optional;

public class CargaServiceImpl implements CargaServicePort {


    private final CargaRepository cargaRepository;

    public CargaServiceImpl(CargaRepository cargaRepository) {
        this.cargaRepository = cargaRepository;
    }

    @Override
    public Carga crearCarga(Carga carga) {
        return cargaRepository.save(carga);
    }

    @Override
    public Optional<Carga> obtenerCargaPorId(Long id) {
        return cargaRepository.findById(id);
    }

    @Override
    public List<Carga> obtenerTodasLasCargas() {
        return cargaRepository.findAll();
    }

    @Override
    public Carga actualizarCarga(Long id, Carga cargaActualizada) {
        return cargaRepository.findById(id)
                .map(carga -> {
                    carga.setPeso(cargaActualizada.getPeso());
                    carga.setDimensiones(cargaActualizada.getDimensiones());
                    carga.setEstado(cargaActualizada.getEstado());
                    return cargaRepository.save(carga);
                }).orElseThrow(() -> new RuntimeException("Carga no encontrada"));
    }

    @Override
    public void eliminarCarga(Long id) {
        cargaRepository.deleteById(id);
    }

    @Override
    public List<Carga> buscarCargasPorFiltros(Estado estado, Double pesoMaximo, Long paletId) {
        Specification<Carga> specification = Specification
                .where(CargaSpecification.withEstado(estado))
                .and(CargaSpecification.withPesoLessThanEqual(pesoMaximo))
                .and(CargaSpecification.withPaletId(paletId));
        return cargaRepository.findAll(specification);
    }

    @Override
    public void actualizarEstadoCarga(Long id, Estado estado) {
        cargaRepository.findById(id)
                .map(carga -> {
                    carga.setEstado(estado);
                    return cargaRepository.save(carga);
                }).orElseThrow(() -> new RuntimeException("Carga no encontrada"));
    }
}
