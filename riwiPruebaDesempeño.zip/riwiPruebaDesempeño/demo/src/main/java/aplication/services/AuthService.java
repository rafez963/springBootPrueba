package aplication.services;

import api.dtos.LoginRequest;
import api.dtos.RegisterRequest;
import api.responses.AuthResponse;
import domain.entities.Transportista;
import domain.repositories.TransportistaRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import utils.config.JwtUtil;

@Service
public class AuthService {


    private final TransportistaRepository usuarioRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;

    public AuthService(TransportistaRepository usuarioRepository, PasswordEncoder passwordEncoder, JwtUtil jwtUtil) {
        this.usuarioRepository = usuarioRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtUtil = jwtUtil;
    }

    public AuthResponse register(RegisterRequest request) {
        Transportista usuario = new Transportista();
        usuario.setEmail(request.getEmail());
        usuario.setPassword(passwordEncoder.encode(request.getPassword()));
        usuario.setRole(request.getRole());

        usuarioRepository.save(usuario);

        String token = jwtUtil.generateToken(usuario);

        AuthResponse response = new AuthResponse();
        response.setToken(token);

        return response;
    }

    public AuthResponse login(LoginRequest request) {
        Transportista  usuario = usuarioRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

        if (!passwordEncoder.matches(request.getPassword(), usuario.getPassword())) {
            throw new RuntimeException("Credenciales incorrectas");
        }

        String token = jwtUtil.generateToken(usuario);

        AuthResponse response = new AuthResponse();
        response.setToken(token);

        return response;
    }
}
