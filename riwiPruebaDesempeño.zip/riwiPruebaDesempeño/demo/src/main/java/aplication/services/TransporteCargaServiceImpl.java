package aplication.services;

import aplication.ports.TransporteCargaServicePort;
import domain.entities.TransporteCarga;
import domain.entities.Transportista;
import domain.repositories.TransporteCargaRepository;
import domain.specifications.TransporteCargaSpecification;
import org.springframework.data.jpa.domain.Specification;

import java.time.LocalDateTime;
import java.util.List;

public class TransporteCargaServiceImpl implements TransporteCargaServicePort {


    private final TransporteCargaRepository transporteCargaRepository;

    public TransporteCargaServiceImpl(TransporteCargaRepository transporteCargaRepository) {
        this.transporteCargaRepository = transporteCargaRepository;
    }

    @Override
    public TransporteCarga registrarTransporteCarga(TransporteCarga transporteCarga) {
        return transporteCargaRepository.save(transporteCarga);
    }

    @Override
    public List<TransporteCarga> buscarTransportesPorFiltros(Long transportistaId, LocalDateTime fechaInicio, LocalDateTime fechaFin) {
        Specification<TransporteCarga> specification = Specification
                .where(TransporteCargaSpecification.withTransportista(transportistaId != null ? new Transportista(transportistaId) : null))
                .and(TransporteCargaSpecification.withFechaTransporteBetween(fechaInicio, fechaFin));
        return transporteCargaRepository.findAll(specification);
    }

}
