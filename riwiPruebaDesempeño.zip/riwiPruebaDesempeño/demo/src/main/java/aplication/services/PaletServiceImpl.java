package aplication.services;

import aplication.ports.PaletServicePort;
import domain.entities.Palet;
import domain.repositories.PaletRepository;
import domain.specifications.PaletSpecification;
import org.springframework.data.jpa.domain.Specification;
import utils.enums.Estado;

import java.util.List;
import java.util.Optional;

public class PaletServiceImpl implements PaletServicePort {

    private final PaletRepository paletRepository;

    public PaletServiceImpl(PaletRepository paletRepository) {
        this.paletRepository = paletRepository;
    }

    @Override
    public Palet crearPalet(Palet palet) {
        return paletRepository.save(palet);
    }

    @Override
    public Optional<Palet> obtenerPaletPorId(Long id) {
        return paletRepository.findById(id);
    }

    @Override
    public List<Palet> obtenerTodosLosPalets() {
        return paletRepository.findAll();
    }

    @Override
    public Palet actualizarPalet(Long id, Palet paletActualizado) {
        return paletRepository.findById(id)
                .map(palet -> {
                    palet.setCapacidadMaxima(paletActualizado.getCapacidadMaxima());
                    palet.setUbicacion(paletActualizado.getUbicacion());
                    palet.setEstado(paletActualizado.getEstado());
                    return paletRepository.save(palet);
                }).orElseThrow(() -> new RuntimeException("Palet no encontrado"));
    }

    @Override
    public void eliminarPalet(Long id) {
        paletRepository.deleteById(id);
    }

    @Override
    public List<Palet> buscarPaletsPorFiltros(Estado estado, Double capacidadMinima, String ubicacion) {
        Specification<Palet> specification = Specification
                .where(PaletSpecification.withEstado(estado))
                .and(PaletSpecification.withCapacidadMaximaGreaterThanEqual(capacidadMinima))
                .and(PaletSpecification.withUbicacion(ubicacion));
        return paletRepository.findAll(specification);
    }
}
