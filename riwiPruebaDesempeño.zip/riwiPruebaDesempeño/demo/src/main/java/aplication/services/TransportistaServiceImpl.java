package aplication.services;

import aplication.ports.TransportistaServicePort;
import domain.entities.Transportista;
import domain.repositories.TransportistaRepository;

import java.util.List;
import java.util.Optional;

public class TransportistaServiceImpl  implements TransportistaServicePort {


    private final TransportistaRepository transportistaRepository;

    public TransportistaServiceImpl(TransportistaRepository transportistaRepository) {
        this.transportistaRepository = transportistaRepository;
    }

    @Override
    public Transportista registrarTransportista(Transportista transportista) {
        return transportistaRepository.save(transportista);
    }

    @Override
    public Optional<Transportista> obtenerTransportistaPorId(Long id) {
        return transportistaRepository.findById(id);
    }

    @Override
    public List<Transportista> obtenerTodosLosTransportistas() {
        return transportistaRepository.findAll();
    }

    @Override
    public void eliminarTransportista(Long id) {
        transportistaRepository.deleteById(id);
    }
}
