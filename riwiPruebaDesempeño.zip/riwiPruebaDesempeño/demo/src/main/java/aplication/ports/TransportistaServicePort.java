package aplication.ports;

import domain.entities.Transportista;

import java.util.List;
import java.util.Optional;

public interface TransportistaServicePort {

    Transportista registrarTransportista(Transportista transportista);
    Optional<Transportista> obtenerTransportistaPorId(Long id);
    List<Transportista> obtenerTodosLosTransportistas();
    void eliminarTransportista(Long id);

}
