package aplication.ports;

import domain.entities.Carga;
import utils.enums.Estado;

import java.util.List;
import java.util.Optional;

public interface CargaServicePort {
    Carga crearCarga(Carga carga);
    Optional<Carga> obtenerCargaPorId(Long id);
    List<Carga> obtenerTodasLasCargas();
    Carga actualizarCarga(Long id, Carga carga);
    void eliminarCarga(Long id);
    List<Carga> buscarCargasPorFiltros(Estado estado, Double pesoMaximo, Long paletId);
    void actualizarEstadoCarga(Long id, Estado estado);
}
