package aplication.ports;

import domain.entities.Palet;
import utils.enums.Estado;

import java.util.List;
import java.util.Optional;

public interface PaletServicePort {

    Palet crearPalet(Palet palet);
    Optional<Palet> obtenerPaletPorId(Long id);
    List<Palet> obtenerTodosLosPalets();
    Palet actualizarPalet(Long id, Palet palet);
    void eliminarPalet(Long id);
    List<Palet> buscarPaletsPorFiltros(Estado estado, Double capacidadMinima, String ubicacion);

}
