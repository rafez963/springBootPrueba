package aplication.ports;

import domain.entities.TransporteCarga;

import java.time.LocalDateTime;
import java.util.List;

public interface TransporteCargaServicePort {
    TransporteCarga registrarTransporteCarga(TransporteCarga transporteCarga);
    List<TransporteCarga> buscarTransportesPorFiltros(Long transportistaId, LocalDateTime fechaInicio, LocalDateTime fechaFin);
}
